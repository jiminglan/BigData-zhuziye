import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class KeyWordList {

	public static void getContent(String filePath, ArrayList<String> listToreplace) {
		BufferedReader bre = null;
		String str = "";
		try {
			bre = new BufferedReader(new FileReader(filePath));
			while ((str = bre.readLine()) != null) {
				listToreplace.add(str);
			}
			bre.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getUserQuest(){
		Scanner reader = new Scanner(System.in); // 控制台等待输入
		String str;
		System.out.print("请输入您想咨询的问题：");
		str = reader.nextLine(); // 获取输入内容，赋给str
		return str;
	}
	
	public static void giveAns(ArrayList<String> listKeyWord, String userQuest){
		if(userQuest.equals("结束")){
			System.exit(0);
		}else{
			ArrayList<String> listKW = new ArrayList<String>(); // 关键字列表
			for (int i = 0; i < listKeyWord.size(); i++) {
				String s = listKeyWord.get(i);
				if (userQuest.indexOf(s) != -1) // 若包含该关键字
					listKW.add(s);
			}
			for (String s : listKW) {
				System.out.println(s);
			}
			userQuest = getUserQuest();
			giveAns(listKeyWord, userQuest);
		}
	}

	public static void main(String[] args) {
		ArrayList<String> listKeyWord = new ArrayList<String>(); // 关键字列表
		
		String userQuest;

		getContent("实体.txt", listKeyWord);
		getContent("属性.txt", listKeyWord);
		getContent("/Users/feifeifeifei/Documents/workspace/GetKeyWord/属性值关键字.txt", listKeyWord);
		getContent("/Users/feifeifeifei/Documents/workspace/GetKeyWord/问题关键字.txt",listKeyWord);
		getContent("/Users/feifeifeifei/Documents/workspace/GetKeyWord/表格关键字.txt", listKeyWord);
		System.out.println(listKeyWord.size());

		userQuest = getUserQuest(); // 由控制台输入获取关键字
		giveAns(listKeyWord, userQuest);
	
	}
}
